package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
   public static byte [] getSHA(String input) throws NoSuchAlgorithmException {
	   MessageDigest md = MessageDigest.getInstance("SHA-256"); //calling the function with a sha-256 encryption: reused
	   return md.digest(input.getBytes(StandardCharsets.UTF_8));//calcculates and returns the input reused
   }
   public String bytesToHEx(byte [] bytes) {
	   //converting the string to hex values :reused previously
	   StringBuilder hString = new StringBuilder ();
	   
	   for (byte bString: bytes) { //computing a for loop to go through all bytes: Reused previously
		   	hString.append(String.format("%02x", bString));
	   }
	   return hString.toString();
	   
	   
   }
   
	@RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
		String hello = "Hello World"; //string to save hello world
		String algoUsed = "SHA-256 Cipher ALgorithm used : "; //saving algorithim used in a string to make the output more clean:reused
    	String data = " Malcolm McGee "; //saving my name in the string
    	MessageDigest md = MessageDigest.getInstance("SHA-256"); //calling the sha-256 function to start the hash :reused 
    	byte [] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));
    	String checkSum = bytesToHEx(hash);//calling bytes to hex function and saving output in checsum:reused 
    	return   "data: " + hello+ "</br></br>" + "<p>Name:" + data + "</br></br>" + algoUsed + checkSum;
	// in the return feel we are first stating the data then printing string. 
    	// we return data and algoused and checksum all in the return with line breaks to clean up the output 
	}
	
	
}
